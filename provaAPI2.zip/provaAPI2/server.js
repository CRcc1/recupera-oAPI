const express = require("express");
const crypto = require('crypto');
const server = express();
let clientes = []
let carros = []
let agendamentos = []
let servicos = []

server.use(express.json())


server.get('/clientes', (req,res)=>{
    return res.json (clientes)
})

server.get('/carros', (req,res)=>{
    return res.json(carros)
})

server.get('/agendamentos', (req,res) => {
    return res.json(agendamentos)
})

server.get('/servicos', (req,res) => {
    return res.json(servicos)
})


server.get('/clientes/:id', (req,res) =>{ //filter
    const id = req.params.id
    const cliente = cliente.filter(u => u.id === id)
    return res.json(cliente)


})


server.get('/carros/:id', (req,res) =>{ //filter
    const id = req.params.id
    const carro = carro.filter(u => u.id === id)
    return res.json(carro)


})

server.get('/servicos/:id', (req,res) =>{ //filter
    const id = req.params.id
    const servico = servico.filter(u => u.id === id)
    return res.json(servico)


})


server.get('/agendamentos/:id', (req,res) =>{ //filter
    const id = req.params.id
    const agendamento = agendamento.filter(u => u.id === id)
    return res.json(agendamento)


})


server.post('/clientes/', (req,res) =>{
    const cliente = req.body

 
    cliente.id = crypto.randomUUID()
    clientes.push(cliente)
    return res.json ("cliente cadastrado com sucesso")


})

server.post('/carros/', (req,res) =>{
    const carro = req.body


    carro.id = crypto.randomUUID()
    carros.push(carro)
    return res.json ("carro cadastrado com sucesso")


})

server.post('/agendamentos/', (req,res) =>{
    const agendamento = req.body


    agendamento.id = crypto.randomUUID()
    agendamentos.push(agendamento)
    return res.json ("Agendamento marcado com sucesso")


})

server.post('/servicos/', (req,res) =>{
    const servico = req.body


    servico.id = crypto.randomUUID()
    servicos.push(servico)
    return res.json ("Serviço cadastrado com sucesso")


})





server.put('/clientes/:id', (req,res) =>{
    const id = req.params.id
    const cliente = req.body
   
   if (nome.cliente.length < 5){
        return res.json("nome muito curso")
    }
    if (nome.cliente.length > 100){
        return res.json ("nome muito longo")
    }
    if (telefone.cliente.length !=11){
        return res.json ("telefone deve ter exatamente 11 caracteres")
    }
    
   


    cliente.id = id
    cliente = cliente.filter(u => u.id != id)
    cliente.push(cliente)
    return res.json("Cliente atualizado com sucesso")


})

server.delete('/clientes/:id', (req,res) =>{
    const id = req.params.id
    clientes = clientes.filter(u => u.id != id)
    return res.json ("cliente deletado com sucesso")

})

server.delete('/carros/:id', (req,res) =>{
    const id = req.params.id
    carros = carros.filter(u => u.id != id)
    return res.json ("carro deletado com sucesso")

})

server.delete('/servicos/:id', (req,res) =>{
    const id = req.params.id
    servicos = servicos.filter(u => u.id != id)
    return res.json ("Serviço deletado com sucesso")

})

server.delete('/agendamentos/:id', (req,res) =>{
    const id = req.params.id
    agendamentos = agendamentos.filter(u => u.id != id)
    return res.json ("Agendamento deletado com sucesso")

})



server.listen(3000, ()=>{
    console.log("server rodando")

})

module.exports = server

















